const stats = [
  { value: "2027", label: "THE SECOND COMING", color: "text-neon-green glow-green" },
  { value: "7", label: "TRUMPETS REMAINING", color: "text-neon-purple glow-purple" },
  { value: "3", label: "SURVIVORS TRAPPED", color: "text-neon-red" },
  { value: "∞", label: "REALITIES BREACHED", color: "text-neon-green glow-green" },
];

const StatsSection = () => {
  return (
    <section className="relative z-10 py-16 border-y border-border/50 noise-overlay">
      <div className="absolute inset-0 bg-gradient-to-r from-neon-green/[0.02] via-transparent to-neon-purple/[0.02]" style={{ background: 'linear-gradient(90deg, hsl(120 100% 50% / 0.02), transparent, hsl(270 80% 55% / 0.02))' }} />
      <div className="container mx-auto px-4 relative z-10">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
          {stats.map((stat) => (
            <div key={stat.label} className="group">
              <p className={`font-orbitron text-4xl md:text-6xl font-bold ${stat.color} transition-all duration-300 group-hover:scale-110`}>{stat.value}</p>
              <p className="font-mono text-[9px] tracking-[0.25em] text-muted-foreground mt-2 uppercase">{stat.label}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Terminal window */}
      <div className="container mx-auto px-4 mt-10 flex justify-between items-end">
        <div className="bg-dark-surface border border-border/50 rounded-lg p-4 max-w-xs w-full backdrop-blur-sm">
          <div className="flex items-center gap-2 mb-3">
            <div className="w-2.5 h-2.5 rounded-full bg-red-500/80" />
            <div className="w-2.5 h-2.5 rounded-full bg-yellow-500/80" />
            <div className="w-2.5 h-2.5 rounded-full bg-green-500/80" />
            <span className="font-mono text-[9px] text-muted-foreground ml-2">DARKENING_STORMS_MONITOR.exe</span>
          </div>
          <p className="font-mono text-xs text-neon-green">
            {">"} ONEBLOCKAWAYREWRITTENTEAM //<span className="border-r-2 border-neon-green animate-blink-cursor ml-1">&nbsp;</span>
          </p>
        </div>

        <div className="hidden md:block text-right">
          <p className="font-mono text-[10px] tracking-[0.2em] text-neon-green">VISIONARY: LOGAN W.</p>
          <p className="font-mono text-[10px] tracking-[0.2em] text-muted-foreground">ONEBLOCKAWAYREWRITTENTEAM</p>
          <p className="font-mono text-[10px] tracking-[0.2em] text-muted-foreground">REWRITTEN MULTIVERSE // ACTIVE</p>
        </div>
      </div>
    </section>
  );
};

export default StatsSection;
