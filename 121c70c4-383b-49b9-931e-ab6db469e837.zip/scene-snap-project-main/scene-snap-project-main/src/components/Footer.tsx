const Footer = () => {
  return (
    <footer id="contact" className="relative z-10 border-t border-border/50 py-16">
      <div className="absolute inset-0 cinematic-gradient opacity-50" />
      <div className="container mx-auto px-4 text-center relative z-10">
        <div className="flex items-center justify-center gap-3 mb-4">
          <div className="w-10 h-10 border border-neon-green/40 rounded-full flex items-center justify-center animate-border-pulse">
            <span className="text-neon-green font-orbitron text-sm font-bold">W</span>
          </div>
          <span className="text-neon-green font-orbitron text-sm font-bold tracking-wider">WRA STUDIOS</span>
        </div>
        <p className="font-mono text-[10px] tracking-[0.2em] text-muted-foreground mb-6">
          ONEBLOCKAWAYREWRITTENTEAM // REWRITTEN MULTIVERSE // ACTIVE
        </p>
        <div className="flex flex-wrap items-center justify-center gap-8 mb-8">
          <a
            href="https://discord.gg/Pt2Upwmt5q"
            target="_blank"
            rel="noopener noreferrer"
            className="font-mono text-xs text-muted-foreground hover:text-neon-green transition-all duration-300 tracking-wider"
          >
            DISCORD
          </a>
          <a
            href="https://youtube.com/@ARTHURTHEBG"
            target="_blank"
            rel="noopener noreferrer"
            className="font-mono text-xs text-muted-foreground hover:text-neon-green transition-all duration-300 tracking-wider"
          >
            YOUTUBE
          </a>
          <a
            href="/vault"
            className="font-mono text-xs text-neon-purple hover:text-neon-green transition-all duration-300 tracking-wider"
          >
            VAULT
          </a>
        </div>
        <div className="w-32 h-[1px] mx-auto mb-6" style={{ background: 'linear-gradient(90deg, transparent, hsl(120 100% 50% / 0.3), transparent)' }} />
        <p className="font-mono text-[10px] text-muted-foreground/40 tracking-wider">
          © 2024 WRA STUDIOS // ALL RIGHTS RESERVED // THE CREATOR IS WATCHING
        </p>
      </div>
    </footer>
  );
};

export default Footer;
