const LoreSection = () => {
  return (
    <section id="lore" className="relative z-10 py-24 border-t border-border/50">
      <div className="absolute inset-0 cinematic-gradient" />
      <div className="container mx-auto px-4 relative z-10">
        <p className="font-mono text-[10px] tracking-[0.3em] text-muted-foreground text-center mb-2">
          [ENTITY DESIGNATION: MASSG] // LORE DATABASE — CLEARANCE GRANTED
        </p>
        <h2 className="font-orbitron text-4xl md:text-6xl font-bold text-center mb-4">
          <span className="text-foreground">ABOUT THE </span>
          <span className="text-neon-green glow-green">LORE</span>
        </h2>
        <div className="w-24 h-[2px] mx-auto mb-4" style={{ background: 'linear-gradient(90deg, transparent, hsl(120 100% 50%), transparent)' }} />
        <p className="text-center text-foreground/70 max-w-2xl mx-auto mb-12 text-sm md:text-base">
          Set after <span className="font-bold text-foreground">Tazo's Broken Secrets</span> and{" "}
          <span className="font-bold text-foreground">Story Mode Season 3</span> — the world is torn apart. MASSG is no
          longer just code. It is <span className="text-neon-red font-bold">awake</span>.
        </p>

        {/* MASSG Entity Card */}
        <div className="max-w-4xl mx-auto grid md:grid-cols-2 gap-8 mb-16">
          <div className="relative rounded-lg overflow-hidden border border-border/50 group hover:border-neon-green/30 transition-all duration-500">
            <img
              src="https://storage.readdy-site.link/project_files/4be922d0-4b7d-410b-b624-fafa1a52468c/90f60bee-7803-4844-b9d8-e36c0866ddf3_IMG_1979.jpeg?v=d8c9dbb94a7d7675ebb863323c21e22d"
              alt="MASSG Entity"
              className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
              loading="lazy"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-background/60 to-transparent" />
            <div className="absolute top-4 left-4">
              <span className="bg-neon-red/20 border border-neon-red text-neon-red font-mono text-[10px] px-3 py-1 rounded animate-pulse backdrop-blur-sm">
                ENTITY SCAN ACTIVE
              </span>
            </div>
          </div>

          <div className="flex flex-col justify-center">
            <h3 className="font-orbitron text-3xl font-bold text-neon-green glow-green mb-1">M.A.S.S.G</h3>
            <p className="font-mono text-xs text-muted-foreground tracking-wider mb-4">
              MASS ANOMALOUS SIGNAL SOURCE GAMMA
            </p>
            <p className="font-mono text-[10px] text-neon-red tracking-wider mb-6">
              — CLASSIFIED DOCUMENT #WRA-MASSG-OMEGA —
            </p>
            <blockquote className="border-l-2 border-neon-green/60 pl-4 text-foreground/80 text-sm leading-relaxed italic">
              "MASSG is no longer just code. It is <span className="font-bold text-foreground">awake</span>. A
              reality-warping entity tearing open the multiverse to survive. It does not destroy. It{" "}
              <span className="font-bold text-foreground">rewrites</span>. Every block placed, every world generated,
              every seed chosen — MASSG was there first."
            </blockquote>
            <p className="font-mono text-[10px] text-muted-foreground tracking-wider mt-4">
              — LOGAN W., VISIONARY // ONEBLOCKAWAYREWRITTENTEAM
            </p>
          </div>
        </div>

        {/* Second Coming warning */}
        <div className="max-w-3xl mx-auto bg-dark-surface/80 backdrop-blur-sm border border-neon-purple/40 rounded-lg p-8 text-center mb-16 box-glow-purple">
          <p className="text-4xl mb-4">🎺</p>
          <h3 className="font-orbitron text-2xl font-bold text-neon-purple glow-purple mb-2">THE SECOND COMING</h3>
          <p className="font-mono text-xs tracking-wider text-muted-foreground mb-4">
            THE 7 TRUMPETS SOUND IN 2027
          </p>
          <p className="text-foreground/70 text-sm max-w-xl mx-auto mb-6 leading-relaxed">
            This is not fiction. This is a countdown. Watch as realities collide and the Devouring Storm approaches. Sub
            to Tazo & Decayed Reality to follow the unfolding.
          </p>
          <div className="bg-neon-red/5 border border-neon-red/30 rounded p-4 mb-6 box-glow-red">
            <p className="font-mono text-[10px] tracking-wider text-neon-red mb-1">⚠ ACTIVE WARNING</p>
            <p className="text-foreground/70 text-xs">
              Anna, Travis, and Tonya are trapped in Decayed Reality. The Devouring Storm approaches. Containment has
              failed. Reality integrity: CRITICAL.
            </p>
          </div>
          <a
            href="https://discord.gg/Pt2Upwmt5q"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex border border-neon-green text-neon-green font-mono text-xs px-6 py-3 rounded hover:bg-neon-green/10 transition-all tracking-wider box-glow-green hover:scale-105 duration-200"
          >
            JOIN THE TRANSMISSION
          </a>
        </div>

        {/* Character dossier */}
        <div className="max-w-4xl mx-auto mb-16">
          <p className="font-mono text-[10px] tracking-[0.3em] text-muted-foreground text-center mb-2">
            // SURVIVOR DOSSIERS //
          </p>
          <h3 className="font-orbitron text-xl font-bold text-center text-foreground mb-8">TRAPPED IN DECAYED REALITY</h3>

          <div className="bg-dark-surface/80 backdrop-blur-sm border border-border/50 rounded-lg overflow-hidden group hover:border-neon-green/30 transition-all duration-500">
            <div className="grid md:grid-cols-2">
              <div className="relative overflow-hidden">
                <img
                  src="https://storage.readdy-site.link/project_files/4be922d0-4b7d-410b-b624-fafa1a52468c/5820461c-0cd2-4c1b-8c68-f8bef2361993_IMG_2465.png?v=ec373da68f0a3d4ec7d602297f9f1345"
                  alt="ANNA — Survivor"
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                  loading="lazy"
                />
                <div className="absolute top-4 left-4">
                  <span className="bg-neon-red/20 border border-neon-red text-neon-red font-mono text-[10px] px-3 py-1 rounded backdrop-blur-sm">
                    STATUS: TRAPPED
                  </span>
                </div>
              </div>
              <div className="p-6 md:p-8 flex flex-col justify-center">
                <h4 className="font-orbitron text-2xl font-bold text-neon-green mb-1">ANNA</h4>
                <p className="font-mono text-xs text-muted-foreground tracking-wider mb-4">Survivor // Decayed Reality</p>
                <p className="text-foreground/70 text-sm leading-relaxed">
                  Caught between colliding realities after the Devouring Storm struck. Anna holds the key to
                  understanding MASSG's true origin — if she can survive long enough to use it.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Document fragments */}
        <div className="max-w-4xl mx-auto">
          <p className="font-mono text-[10px] tracking-[0.3em] text-muted-foreground text-center mb-8">
            // RECOVERED TRANSMISSION FRAGMENTS //
          </p>
          <div className="grid md:grid-cols-3 gap-6">
            {[
              {
                id: "DOC-001",
                level: "LEVEL OMEGA",
                title: "MASSG AWAKENS",
                text: "MASSG is no longer just code. It is awake. A reality-warping entity that has torn open the multiverse to survive. It does not destroy — it rewrites.",
              },
              {
                id: "DOC-002",
                level: "LEVEL SIGMA",
                title: "THE DEVOURING STORM",
                text: "The Devouring Storm is MASSG's physical manifestation in our dimension. Where it passes, reality collapses. Blocks become memories. Time becomes optional.",
              },
              {
                id: "DOC-003",
                level: "LEVEL OMEGA",
                title: "THE SECOND COMING",
                text: "Set after Tazo's Broken Secrets and Story Mode S3. The 7 Trumpets will sound in 2027. This is not a metaphor. This is a countdown.",
              },
            ].map((doc) => (
              <div
                key={doc.id}
                className="bg-dark-surface/80 backdrop-blur-sm border border-border/50 rounded-lg p-6 hover:border-neon-green/30 transition-all duration-500 group"
              >
                <div className="flex items-center gap-2 mb-3">
                  <span className="font-mono text-[10px] text-neon-green tracking-wider">{doc.id}</span>
                  <span className="font-mono text-[10px] text-neon-red tracking-wider">{doc.level}</span>
                </div>
                <h4 className="font-orbitron text-sm font-bold text-foreground mb-3 group-hover:text-neon-green transition-colors">{doc.title}</h4>
                <p className="text-foreground/60 text-sm leading-relaxed">{doc.text}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default LoreSection;
