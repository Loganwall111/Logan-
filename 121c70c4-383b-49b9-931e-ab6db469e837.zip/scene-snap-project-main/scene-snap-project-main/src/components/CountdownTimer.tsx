import { useState, useEffect } from "react";

const TARGET_DATE = new Date("2027-01-01T00:00:00Z").getTime();

const CountdownTimer = () => {
  const [timeLeft, setTimeLeft] = useState(getTimeLeft());

  function getTimeLeft() {
    const diff = TARGET_DATE - Date.now();
    if (diff <= 0) return { days: 0, hrs: 0, min: 0, sec: 0 };
    return {
      days: Math.floor(diff / (1000 * 60 * 60 * 24)),
      hrs: Math.floor((diff / (1000 * 60 * 60)) % 24),
      min: Math.floor((diff / (1000 * 60)) % 60),
      sec: Math.floor((diff / 1000) % 60),
    };
  }

  useEffect(() => {
    const interval = setInterval(() => setTimeLeft(getTimeLeft()), 1000);
    return () => clearInterval(interval);
  }, []);

  const pad = (n: number) => String(n).padStart(2, "0");

  return (
    <div className="border border-neon-purple/40 rounded-lg p-6 md:p-8 box-glow-purple max-w-2xl mx-auto backdrop-blur-sm bg-dark-surface/30">
      <p className="text-center font-mono text-sm tracking-[0.3em] text-neon-purple mb-6">
        🎺 THE 7 TRUMPETS — COUNTDOWN TO 2027 🎺
      </p>
      <div className="flex items-center justify-center gap-2 md:gap-4">
        {[
          { value: timeLeft.days, label: "DAYS" },
          { value: timeLeft.hrs, label: "HRS" },
          { value: timeLeft.min, label: "MIN" },
          { value: timeLeft.sec, label: "SEC", glow: true },
        ].map((item, i) => (
          <div key={item.label} className="flex items-center gap-2 md:gap-4">
            {i > 0 && <span className="text-neon-green/50 font-orbitron text-2xl md:text-4xl">:</span>}
            <div className="text-center">
              <span
                className={`font-orbitron text-3xl md:text-6xl font-bold ${
                  item.glow ? "text-neon-green glow-green animate-pulse-glow" : "text-foreground"
                }`}
              >
                {item.label === "DAYS" ? timeLeft.days : pad(item.value)}
              </span>
              <p className="font-mono text-[9px] md:text-[10px] tracking-[0.3em] text-muted-foreground mt-1">
                {item.label}
              </p>
            </div>
          </div>
        ))}
      </div>
      <p className="text-center font-mono text-[10px] tracking-[0.3em] text-neon-green/70 mt-5">
        ● THE SECOND COMING // REALITY BREACH IMMINENT ●
      </p>
    </div>
  );
};

export default CountdownTimer;
