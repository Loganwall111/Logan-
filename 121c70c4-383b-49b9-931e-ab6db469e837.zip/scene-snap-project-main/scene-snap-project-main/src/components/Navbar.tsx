import { useState, useEffect } from "react";
import { Menu, X } from "lucide-react";

const navLinks = [
  { label: "PROJECTS", href: "#projects" },
  { label: "SHOWCASE", href: "#showcase" },
  { label: "LORE", href: "#lore" },
  { label: "CONTACT", href: "#contact" },
  { label: "VAULT", href: "/vault" },
  { label: "OLD SITE", href: "https://readdy.ai/home/dpxhd0g17pxi0fz", external: true },
];

const Navbar = () => {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${scrolled ? 'bg-background/95 backdrop-blur-lg border-b border-border shadow-[0_0_30px_hsl(120_100%_50%/0.05)]' : 'bg-transparent'}`}>
      <div className="container mx-auto flex items-center justify-between h-16 px-4">
        <a href="/" className="flex items-center gap-3 group">
          <div className="w-9 h-9 border border-neon-green/60 rounded-full flex items-center justify-center group-hover:border-neon-green transition-colors group-hover:shadow-[0_0_15px_hsl(120_100%_50%/0.3)]">
            <span className="text-neon-green font-orbitron text-xs font-bold">W</span>
          </div>
          <div>
            <span className="text-neon-green font-orbitron text-sm font-bold tracking-wider">WRA STUDIOS</span>
            <p className="text-muted-foreground font-mono text-[10px] tracking-widest">DARKENING STORMS</p>
          </div>
        </a>

        <div className="hidden md:flex items-center gap-8">
          {navLinks.map((link) => (
            <a
              key={link.label}
              href={link.href}
              {...(link.external ? { target: "_blank", rel: "noopener noreferrer" } : {})}
              className={`font-mono text-[11px] tracking-[0.2em] transition-all duration-300 hover:text-neon-green ${
                link.label === 'VAULT' ? 'text-neon-purple hover:text-neon-purple animate-pulse' : 'text-muted-foreground'
              }`}
            >
              {link.label}
            </a>
          ))}
        </div>

        <a
          href="https://discord.gg/Pt2Upwmt5q"
          target="_blank"
          rel="noopener noreferrer"
          className="hidden md:flex items-center gap-2 border border-neon-green text-neon-green font-mono text-[11px] px-5 py-2 rounded hover:bg-neon-green/10 transition-all tracking-wider hover:shadow-[0_0_20px_hsl(120_100%_50%/0.3)]"
        >
          ⊕ JOIN DISCORD
        </a>

        <button className="md:hidden text-foreground" onClick={() => setOpen(!open)}>
          {open ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {open && (
        <div className="md:hidden bg-background/95 backdrop-blur-lg border-b border-border px-4 pb-4">
          {navLinks.map((link) => (
            <a
              key={link.label}
              href={link.href}
              {...(link.external ? { target: "_blank", rel: "noopener noreferrer" } : {})}
              className="block py-2.5 text-muted-foreground font-mono text-sm tracking-widest hover:text-neon-green transition-colors"
              onClick={() => setOpen(false)}
            >
              {link.label}
            </a>
          ))}
        </div>
      )}
    </nav>
  );
};

export default Navbar;
