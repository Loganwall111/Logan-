const projects = [
  {
    title: "Darkening Storms",
    subtitle: "Epic Minecraft Cinematic Series",
    description:
      "Set after Tazo's Broken Secrets and Story Mode Season 3. The world is torn apart. Watch as Anna, Travis, and Tonya navigate a Decayed Reality while the Devouring Storm closes in. Realities collide. MASSG awakens.",
    image:
      "https://storage.readdy-site.link/project_files/4be922d0-4b7d-410b-b624-fafa1a52468c/adb5eef9-6141-4887-b1bf-465a1fff30f1_IMG_2425.jpeg?v=20be1673187d5ac6e27b564825d0c988",
    status: "IN PRODUCTION",
    clearance: "CLEARANCE: OMEGA",
    featured: true,
    progress: 62,
    tags: ["CINEMATIC SERIES", "STORY MODE S3", "MASSG LORE"],
    type: "SERIES // EPISODE 1",
    link: "https://discord.gg/Pt2Upwmt5q",
    linkText: "JOIN DISCORD →",
  },
  {
    title: "MCSM 1:1 Mod Replica",
    subtitle: "Minecraft Story Mode Faithful Recreation",
    description:
      "A faithful 1:1 mod replica of Minecraft Story Mode. Every block, every scene, every moment — rebuilt from the ground up inside Minecraft. Download available now.",
    image:
      "https://storage.readdy-site.link/project_files/4be922d0-4b7d-410b-b624-fafa1a52468c/afd5b77b-4e98-4eaa-8f54-cf8977592d3b_IMG_2426.jpeg?v=8a91fb4ecbebde328e488d88aea27c5a",
    status: "AVAILABLE",
    featured: false,
    progress: 85,
    tags: ["MOD", "MCSM", "DOWNLOAD"],
    type: "MOD // REPLICA BUILD",
    link: "https://drive.google.com/file/d/1ynI66iNhDxi1zkSVArBedWji4HS_FKaw/view",
    linkText: "DOWNLOAD →",
  },
  {
    title: "Decayed Reality Collab",
    subtitle: "Sub to Tazo & Decayed Reality",
    description:
      "A cross-universe collaboration with the Decayed Reality team. When two corrupted timelines intersect, the rules of Minecraft no longer apply. Join the Decayed Team community.",
    image:
      "https://storage.readdy-site.link/project_files/4be922d0-4b7d-410b-b624-fafa1a52468c/16ad5f31-d0cf-4d16-a030-d855f35dbec4_IMG_2482.jpeg?v=a2c41a53b8686cbf05000eee4f41a557",
    status: "ONGOING",
    featured: false,
    progress: 40,
    tags: ["COLLAB", "DECAYED REALITY", "MULTIVERSE"],
    type: "COLLAB // DECAYED REALITY",
    link: "https://discord.com/invite/decayed-team-community-1001457341985726465",
    linkText: "JOIN →",
  },
];

const ProjectsSection = () => {
  return (
    <section id="projects" className="relative z-10 py-24">
      <div className="container mx-auto px-4">
        <p className="font-mono text-[10px] tracking-[0.3em] text-muted-foreground text-center mb-2">
          [REWRITTEN MULTIVERSE] // ACTIVE PROJECTS DATABASE
        </p>
        <h2 className="font-orbitron text-4xl md:text-6xl font-bold text-center mb-4">
          <span className="text-neon-green glow-green">COMING</span>{" "}
          <span className="text-neon-purple glow-purple">SOON</span>
        </h2>
        <div className="w-24 h-[2px] mx-auto mb-4" style={{ background: 'linear-gradient(90deg, hsl(120 100% 50%), hsl(270 80% 55%))' }} />
        <p className="text-center text-foreground/70 max-w-2xl mx-auto mb-16 text-sm md:text-base">
          Welcome to the <span className="font-bold text-foreground">Rewritten Multiverse</span>. These are the
          classified transmissions from the Oneblockawayrewrittenteam — developing the future of Minecraft storytelling.
        </p>

        <div className="space-y-12">
          {projects.map((project) => (
            <div
              key={project.title}
              className="bg-dark-surface/80 backdrop-blur-sm border border-border/50 rounded-lg overflow-hidden hover:border-neon-green/40 transition-all duration-500 group hover:shadow-[0_0_40px_hsl(120_100%_50%/0.08)]"
            >
              <div className="grid md:grid-cols-2">
                <div className="relative h-64 md:h-auto overflow-hidden">
                  <img
                    src={project.image}
                    alt={project.title}
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                    loading="lazy"
                  />
                  <div className="absolute inset-0 bg-gradient-to-r from-transparent to-background/30" />
                  {project.featured && (
                    <div className="absolute top-4 left-4">
                      <span className="bg-neon-green/20 border border-neon-green text-neon-green font-mono text-[10px] px-3 py-1 rounded tracking-wider backdrop-blur-sm">
                        ◆ FEATURED PROJECT
                      </span>
                    </div>
                  )}
                </div>

                <div className="p-6 md:p-8 flex flex-col justify-center">
                  <div className="flex items-center gap-2 mb-2">
                    <span className="bg-neon-green/15 text-neon-green font-mono text-[10px] px-2 py-0.5 rounded tracking-wider">
                      {project.status}
                    </span>
                    <span className="font-mono text-[10px] text-muted-foreground tracking-wider">{project.type}</span>
                    {project.clearance && (
                      <span className="font-mono text-[10px] text-neon-red tracking-wider">{project.clearance}</span>
                    )}
                  </div>

                  <h3 className="font-orbitron text-xl md:text-2xl font-bold text-foreground mb-1">{project.title}</h3>
                  <p className="font-mono text-xs text-muted-foreground mb-4">{project.subtitle}</p>
                  <p className="text-foreground/70 text-sm mb-6 leading-relaxed">{project.description}</p>

                  {/* Progress bar */}
                  <div className="mb-4">
                    <div className="flex justify-between items-center mb-1">
                      <span className="font-mono text-[10px] tracking-wider text-muted-foreground">
                        {project.featured ? "PRODUCTION " : ""}PROGRESS
                      </span>
                      <span className="font-mono text-xs text-neon-green">{project.progress}%</span>
                    </div>
                    <div className="h-1.5 bg-border/50 rounded-full overflow-hidden">
                      <div
                        className="h-full rounded-full transition-all duration-1000"
                        style={{
                          width: `${project.progress}%`,
                          background: "linear-gradient(90deg, hsl(120 100% 50%), hsl(270 80% 55%))",
                          boxShadow: "0 0 10px hsl(120 100% 50% / 0.5)",
                        }}
                      />
                    </div>
                  </div>

                  <div className="flex flex-wrap gap-2 mb-6">
                    {project.tags.map((tag) => (
                      <span
                        key={tag}
                        className="bg-dark-elevated/80 border border-border/50 font-mono text-[10px] px-3 py-1 rounded text-muted-foreground tracking-wider"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>

                  <a
                    href={project.link}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 border border-neon-green text-neon-green font-mono text-xs px-6 py-2.5 rounded hover:bg-neon-green/10 transition-all tracking-wider w-fit hover:shadow-[0_0_15px_hsl(120_100%_50%/0.3)]"
                  >
                    {project.linkText}
                  </a>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Allied transmission */}
        <div className="mt-12 bg-dark-surface/80 backdrop-blur-sm border border-border/50 rounded-lg p-6 md:p-8 text-center hover:border-neon-purple/30 transition-colors duration-500">
          <p className="font-mono text-[10px] tracking-[0.3em] text-muted-foreground mb-2">ALLIED TRANSMISSION</p>
          <h3 className="font-orbitron text-xl font-bold text-foreground mb-2">ARTHURTHEBG</h3>
          <p className="text-foreground/70 text-sm mb-4">
            A homie in the multiverse. Check out Arthur's channel for more Minecraft content from the allied network.
          </p>
          <a
            href="https://youtube.com/@ARTHURTHEBG"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 border border-neon-purple text-neon-purple font-mono text-xs px-6 py-2.5 rounded hover:bg-neon-purple/10 transition-all tracking-wider hover:shadow-[0_0_15px_hsl(270_80%_55%/0.3)]"
          >
            VISIT CHANNEL →
          </a>
        </div>
      </div>
    </section>
  );
};

export default ProjectsSection;
