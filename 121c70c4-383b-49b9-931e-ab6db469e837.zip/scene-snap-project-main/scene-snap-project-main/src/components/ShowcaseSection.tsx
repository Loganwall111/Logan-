const ShowcaseSection = () => {
  return (
    <section id="showcase" className="relative z-10 py-24 border-t border-border/50">
      <div className="container mx-auto px-4">
        <p className="font-mono text-[10px] tracking-[0.3em] text-muted-foreground text-center mb-2">
          [VISUAL TRANSMISSION] // DARKENING STORMS SHOWCASE
        </p>
        <h2 className="font-orbitron text-4xl md:text-6xl font-bold text-center mb-4">
          <span className="text-foreground">THE </span>
          <span className="text-neon-green glow-green">MULTIVERSE</span>
        </h2>
        <div className="w-24 h-[2px] mx-auto mb-4" style={{ background: 'linear-gradient(90deg, transparent, hsl(120 100% 50%), transparent)' }} />
        <p className="text-center text-foreground/70 max-w-2xl mx-auto mb-12 text-sm md:text-base">
          Visual transmissions from the <span className="font-bold text-foreground">Rewritten Multiverse</span>. Concept
          art, in-game captures, and classified imagery from the Darkening Storms production.
        </p>

        {/* Showcase image */}
        <div className="relative rounded-lg overflow-hidden border border-border/50 mb-12 max-w-4xl mx-auto group hover:border-neon-green/30 transition-all duration-500 hover:shadow-[0_0_50px_hsl(120_100%_50%/0.1)]">
          <img
            src="https://storage.readdy-site.link/project_files/4be922d0-4b7d-410b-b624-fafa1a52468c/e59ad9f0-d55d-4bf6-8dcb-5b4fbf0f7e7f_IMG_2498.jpeg?v=93ae6957ce27d5bf5b03b17fa374a1d6"
            alt="Darkening Storms — Rewritten Multiverse Showcase"
            className="w-full object-cover transition-transform duration-700 group-hover:scale-105"
            loading="lazy"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-background via-background/20 to-transparent" />
          <div className="absolute bottom-4 left-4">
            <p className="font-mono text-[10px] tracking-wider text-neon-green mb-1">
              CLASSIFIED VISUAL // DARKENING STORMS
            </p>
            <p className="font-mono text-[10px] tracking-wider text-muted-foreground">
              REWRITTEN MULTIVERSE — CONCEPT ART
            </p>
          </div>
          <div className="absolute top-4 right-4">
            <span className="bg-neon-green/20 border border-neon-green text-neon-green font-mono text-[10px] px-3 py-1 rounded backdrop-blur-sm animate-pulse">
              TRANSMISSION ACTIVE
            </span>
          </div>
        </div>

        {/* Three info cards */}
        <div className="grid md:grid-cols-3 gap-6 max-w-4xl mx-auto">
          {[
            {
              title: "CINEMATIC SERIES",
              text: "Darkening Storms is an epic Minecraft cinematic series set after Tazo's Broken Secrets and Story Mode S3. Watch as realities collide.",
              accent: "neon-green",
            },
            {
              title: "1:1 MOD REPLICA",
              text: "Every scene faithfully recreated inside Minecraft. Download the MCSM mod replica and experience the story firsthand.",
              accent: "neon-purple",
            },
            {
              title: "LIVE PRODUCTION",
              text: "Currently in active production. Join the Discord to follow development updates and get early access to classified transmissions.",
              accent: "neon-green",
            },
          ].map((card) => (
            <div key={card.title} className="bg-dark-surface/80 backdrop-blur-sm border border-border/50 rounded-lg p-6 hover:border-neon-green/30 transition-all duration-500 group">
              <div className="w-8 h-[2px] mb-4" style={{ background: card.accent === 'neon-green' ? 'hsl(120 100% 50%)' : 'hsl(270 80% 55%)' }} />
              <h3 className={`font-orbitron text-sm font-bold mb-3 ${card.accent === 'neon-green' ? 'text-neon-green' : 'text-neon-purple'}`}>{card.title}</h3>
              <p className="text-foreground/70 text-sm leading-relaxed">{card.text}</p>
            </div>
          ))}
        </div>

        <div className="flex flex-wrap items-center justify-center gap-4 mt-10">
          <a
            href="https://discord.gg/Pt2Upwmt5q"
            target="_blank"
            rel="noopener noreferrer"
            className="border border-neon-green text-neon-green font-mono text-xs px-6 py-3 rounded hover:bg-neon-green/10 transition-all tracking-wider box-glow-green hover:scale-105 duration-200"
          >
            JOIN THE DISCORD
          </a>
          <a
            href="https://drive.google.com/file/d/1ynI66iNhDxi1zkSVArBedWji4HS_FKaw/view"
            target="_blank"
            rel="noopener noreferrer"
            className="border border-neon-purple text-neon-purple font-mono text-xs px-6 py-3 rounded hover:bg-neon-purple/10 transition-all tracking-wider hover:scale-105 duration-200"
          >
            DOWNLOAD MCSM MOD
          </a>
        </div>
      </div>
    </section>
  );
};

export default ShowcaseSection;
