import CountdownTimer from "./CountdownTimer";

const HeroSection = () => {
  return (
    <section className="relative min-h-screen flex flex-col items-center justify-center text-center px-4 pt-20 pb-12 overflow-hidden">
      {/* Layered cinematic background */}
      <div
        className="absolute inset-0 z-0 opacity-25 scale-110"
        style={{
          backgroundImage:
            "url(https://storage.readdy-site.link/project_files/4be922d0-4b7d-410b-b624-fafa1a52468c/90f60bee-7803-4844-b9d8-e36c0866ddf3_IMG_1979.jpeg?v=d8c9dbb94a7d7675ebb863323c21e22d)",
          backgroundSize: "cover",
          backgroundPosition: "center",
          filter: "blur(2px) saturate(0.7)",
        }}
      />
      {/* Color atmosphere overlays */}
      <div className="absolute inset-0 z-0 cinematic-gradient" />
      <div className="absolute inset-0 z-0 bg-gradient-to-b from-background/40 via-background/70 to-background" />
      <div className="absolute inset-0 z-0 bg-gradient-to-r from-background/50 via-transparent to-background/50" />
      <div className="absolute inset-0 z-0 vignette" />
      
      {/* Animated scan line */}
      <div className="absolute inset-0 z-[2] pointer-events-none overflow-hidden">
        <div className="w-full h-[2px] bg-gradient-to-r from-transparent via-neon-green/20 to-transparent animate-scan" style={{ background: 'linear-gradient(90deg, transparent, hsl(120 100% 50% / 0.15), transparent)' }} />
      </div>

      <div className="relative z-10 max-w-5xl mx-auto space-y-6">
        {/* Studio header */}
        <div className="flex items-center justify-center gap-3 mb-2 animate-fade-in">
          <div className="w-12 h-12 border border-neon-green/40 rounded-full flex items-center justify-center animate-border-pulse backdrop-blur-sm bg-background/20">
            <span className="text-neon-green font-orbitron text-base font-bold">W</span>
          </div>
          <div className="text-left">
            <p className="text-neon-green font-orbitron text-xs md:text-sm font-bold tracking-[0.25em]">
              WITHERING REWRITE AWAKENING STUDIOS
            </p>
            <p className="text-muted-foreground font-mono text-[10px] tracking-[0.2em]">
              ONEBLOCKAWAYREWRITTENTEAM // VISIONARY: LOGAN W.
            </p>
          </div>
        </div>

        {/* Classification badge */}
        <div className="inline-block border border-neon-red/40 bg-neon-red/5 backdrop-blur-sm rounded px-6 py-2 box-glow-red">
          <p className="font-mono text-[10px] md:text-xs tracking-[0.2em] text-neon-red flex items-center gap-2">
            <span className="inline-block w-2 h-2 bg-red-500 rounded-full animate-pulse" />
            TOP SECRET // SET AFTER TAZO'S BROKEN SECRETS & STORY MODE S3
          </p>
        </div>

        {/* Main title — cinematic with glitch */}
        <div className="space-y-1 py-4">
          <h1
            className="font-orbitron text-7xl md:text-[10rem] font-black tracking-wider text-white leading-[0.85] animate-flicker glitch-text"
            data-text="DARKENING"
            style={{
              textShadow: '0 0 20px hsl(120 100% 50% / 0.5), 0 0 60px hsl(120 100% 50% / 0.3), 0 0 100px hsl(120 100% 50% / 0.15), 0 2px 0 hsl(270 80% 55% / 0.3)'
            }}
          >
            DARKENING
          </h1>
          <p
            className="font-orbitron text-6xl md:text-[9rem] font-black tracking-wider text-neon-green leading-[0.9]"
            style={{
              textShadow: '0 0 30px hsl(120 100% 50% / 0.7), 0 0 80px hsl(120 100% 50% / 0.4), 0 0 140px hsl(120 100% 50% / 0.2)'
            }}
          >
            STORMS
          </p>
        </div>

        <p className="font-mono text-[11px] md:text-sm tracking-[0.35em] text-muted-foreground uppercase">
          An Epic Minecraft Cinematic Series & 1:1 Mod Replica
        </p>

        <p className="text-foreground/80 max-w-2xl mx-auto text-sm md:text-base leading-relaxed">
          The world is torn apart. <span className="text-neon-green font-bold">MASSG</span> is no longer just code — it is{" "}
          <span className="text-neon-red font-bold italic">awake</span>. A reality-warping entity tearing open the multiverse to survive.
        </p>

        <p className="font-mono text-[10px] md:text-xs tracking-[0.2em] text-neon-purple">
          ANNA · TRAVIS · TONYA — TRAPPED IN DECAYED REALITY // THE DEVOURING STORM APPROACHES
        </p>

        {/* Countdown */}
        <CountdownTimer />

        {/* Action buttons */}
        <div className="flex flex-wrap items-center justify-center gap-3 pt-4">
          <a
            href="https://discord.gg/Pt2Upwmt5q"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-2 bg-neon-green/10 border border-neon-green text-neon-green font-mono text-xs px-6 py-3 rounded hover:bg-neon-green/20 transition-all tracking-wider box-glow-green hover:scale-105 duration-200"
          >
            🔒 JOIN THE DISCORD
          </a>
          <a
            href="#projects"
            className="flex items-center gap-2 border border-neon-purple/60 text-neon-purple font-mono text-xs px-6 py-3 rounded hover:bg-neon-purple/10 hover:border-neon-purple transition-all tracking-wider hover:scale-105 duration-200"
          >
            ⊕ VIEW PROJECTS
          </a>
          <a
            href="/vault"
            className="flex items-center gap-2 border border-neon-red/40 text-neon-red/80 font-mono text-xs px-6 py-3 rounded hover:border-neon-red hover:text-neon-red hover:bg-neon-red/5 transition-all tracking-wider hover:scale-105 duration-200 box-glow-red"
          >
            ☠ DECRYPT LORE
          </a>
          <button
            onClick={() => navigator.clipboard?.writeText(window.location.href)}
            className="flex items-center gap-2 border border-border text-muted-foreground font-mono text-xs px-6 py-3 rounded hover:border-neon-green/50 hover:text-neon-green transition-all tracking-wider hover:scale-105 duration-200"
          >
            ⤴ SHARE SITE
          </button>
        </div>
      </div>

      {/* Bottom fade with terminal line */}
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-background to-transparent z-[3]" />
    </section>
  );
};

export default HeroSection;
