import Navbar from "@/components/Navbar";
import HeroSection from "@/components/HeroSection";
import StatsSection from "@/components/StatsSection";
import ProjectsSection from "@/components/ProjectsSection";
import ShowcaseSection from "@/components/ShowcaseSection";
import LoreSection from "@/components/LoreSection";
import Footer from "@/components/Footer";
import Particles from "@/components/Particles";

const Index = () => {
  return (
    <div className="relative min-h-screen grid-bg scanline noise-overlay">
      <Particles />
      <Navbar />
      <HeroSection />
      <StatsSection />
      <ProjectsSection />
      <ShowcaseSection />
      <LoreSection />
      <Footer />
    </div>
  );
};

export default Index;
