import React, { useState, useEffect, useRef } from 'react';
import {
  Terminal, Database, FileText, Lock, Camera,
  Mail, Map, Globe, Trash2, Power, User,
  AlertTriangle, Eye, Ghost, Cpu, Monitor,
  Skull, Activity, Zap, HardDrive, Wifi, Radio,
  Search, ChevronRight, X, Minus, Maximize2,
  ShieldAlert, Download, Volume2, Settings,
  Play, Image, Film
} from 'lucide-react';

const apiKey = "";

// --- CLASSIFIED DATA REPOSITORY ---
const LORE_DB = {
  characters: [
    { name: "Anna", id: "SUB-001", status: "CORE_COMPROMISED", lore: "Subject displayed blue-eye mutation at 16:15. Consciousness has been fragmented into the world seed." },
    { name: "Travis", id: "SUB-002", status: "EVADING", lore: "Lead dev. Attempted to delete the 'MASSG' directory. Currently being stalked by Void Entities." },
    { name: "Tonya", id: "SUB-003", status: "LOST_IN_TRANSMISSION", lore: "Last broadcast from Tazo Terminal. Signal was replaced by a recursive audio loop of her own screaming." }
  ],
  entities: [
    { name: "The Creator", type: "PRIME_ARCHITECT", threat: "EXTREME", description: "Sentient source code. Views the multiverse as a trash bin for failed realities." },
    { name: "The Wither Storm", type: "CLEANUP_DAEMON", threat: "HIGH", description: "A glitched deletion script that consumes block data to increase its mass." }
  ]
};

const DEV_BUILDS = [
  { name: "MASSG_v0.1_STABLE_BUILD.exe", size: "4.2 GB", date: "04-03-94", desc: "Original reality bridge." },
  { name: "VOID_RENDERER_BETA.dll", size: "128 MB", date: "05-12-94", desc: "Allows viewing of the 4th dimension." },
  { name: "BLUE_EYE_PATCH.zip", size: "1.5 GB", date: "06-01-94", desc: "WARNING: Do not execute." }
];

const CCTV_NODES = [
  { id: 1, name: "NODE_01: SECTOR_4", prompt: "Security camera footage, grainy green phosphor style, Minecraft character staring into the camera with glowing blue eyes, long dark hallway, analog horror." },
  { id: 2, name: "NODE_02: THE_VOID", prompt: "Found footage, distorted green static, a giant pixelated eye opening in a black sky, glitched Minecraft terrain." },
  { id: 3, name: "NODE_03: REALITY_LEAK", prompt: "A dark real-life basement, a glowing Minecraft purple block floating in the corner, flickering green phosphor lights, high contrast horror." }
];

const ENCRYPTED_MAIL = [
  { from: "CREATOR", subject: "DELETION_NOTICE", body: "Sector 7 is unresponsive. Purge the seed immediately. Do not save the children." },
  { from: "ADMIN_01", subject: "RE: ANNA", body: "She isn't eating. She just stares at the water. Her eyes... they're glowing." },
  { from: "SYSTEM", subject: "FATAL_ERROR", body: "The multiverse has exceeded its storage capacity. Reality bleed imminent." }
];

const SCRIPT_ACTS = [
  { id: 'act1', title: 'THE DISCOVERY', duration: 12000, prompt: 'Cinematic Minecraft beach, toxic green waves, Travis holding a spinning compass, high-end shaders, horror lighting.', dialogue: { speaker: 'TRAVIS', text: "Anna, the water... it's not blue anymore. It's... code.", voice: 'Puck' } },
  { id: 'act2', title: 'THE MUTATION', duration: 8000, prompt: 'Close up of Anna, eyes turning neon blue, skin pixelating into green static, cinematic 3D horror.', dialogue: { speaker: 'ANNA', text: 'I can hear the Creator. He wants us to come home.', voice: 'Kore' }, scare: true },
  { id: 'act3', title: 'THE MASSG PROTOCOL', duration: 15000, prompt: 'A massive green vortex rift in the sky, Minecraft blocks flying into it, The Creator standing in the center.', dialogue: { speaker: 'CREATOR', text: 'THE DELETION IS FINAL. DO NOT LOOK BACK.', voice: 'Fenrir' }, scare: true }
];

// --- CORE OS COMPONENTS ---
const VHSOverlay = ({ color = "white" }: { color?: string }) => (
  <div className="absolute inset-0 pointer-events-none z-50 overflow-hidden" style={{ mixBlendMode: 'screen' }}>
    <div className="absolute inset-0" style={{ background: `repeating-linear-gradient(0deg, rgba(0,0,0,0.15) 0px, rgba(0,0,0,0.15) 1px, transparent 1px, transparent 2px)` }} />
    <div className="absolute inset-0 animate-pulse opacity-[0.03]" style={{ background: `linear-gradient(180deg, transparent, ${color}, transparent)`, animationDuration: '3s' }} />
    <div className="absolute top-4 left-4 font-mono text-[10px] tracking-widest" style={{ color }}>
      PLAY ▶<br />00:34:12:09
    </div>
    <div className="absolute bottom-4 right-4 font-mono text-[10px] tracking-widest" style={{ color }}>
      SP MODE // TRACKING AUTO
    </div>
  </div>
);

interface DesktopIconProps {
  icon: React.ElementType;
  label: string;
  onClick: () => void;
  color?: string;
}

const DesktopIcon = ({ icon: Icon, label, onClick, color = "text-green-500" }: DesktopIconProps) => (
  <button onClick={onClick} className="flex flex-col items-center gap-1 p-2 hover:bg-white/5 rounded transition-all group w-[72px]">
    <div className={`${color} group-hover:scale-110 transition-transform`}>
      {Icon ? <Icon size={28} /> : null}
    </div>
    <span className="text-[9px] text-center font-mono text-zinc-400 leading-tight break-all">
      {label}
    </span>
  </button>
);

interface DraggableWindowProps {
  id: string;
  title: string;
  icon: React.ElementType;
  onClose: () => void;
  children: React.ReactNode;
  isActive: boolean;
  onFocus: () => void;
  position: { x: number; y: number };
  onDragStart: (e: React.MouseEvent | React.TouchEvent) => void;
}

const DraggableWindow = ({ id, title, icon: Icon, onClose, children, isActive, onFocus, position, onDragStart }: DraggableWindowProps) => (
  <div
    onClick={onFocus}
    className="absolute shadow-2xl"
    style={{
      left: position.x,
      top: position.y,
      zIndex: isActive ? 4000 : 3000,
      width: 'clamp(300px, 60vw, 500px)',
      maxHeight: '70vh',
    }}
  >
    <div
      onMouseDown={onDragStart}
      onTouchStart={onDragStart}
      className={`flex items-center justify-between px-2 py-1 cursor-move select-none ${isActive ? 'bg-[#000080]' : 'bg-zinc-600'}`}
    >
      <div className="flex items-center gap-2 text-white font-bold text-[11px] truncate">
        <Icon size={12} />
        {title}
      </div>
      <div className="flex gap-1">
        <button onClick={(e) => { e.stopPropagation(); onClose(); }} className="w-4 h-4 bg-[#c0c0c0] border border-b-zinc-800 border-r-zinc-800 flex items-center justify-center text-black hover:bg-red-600 hover:text-white">
          <X size={8} />
        </button>
      </div>
    </div>
    <div className="bg-[#0a0a0a] border border-zinc-700 overflow-y-auto" style={{ maxHeight: 'calc(70vh - 28px)' }}>
      {children}
    </div>
  </div>
);

// --- MASSG OS ---
const MassgOS = () => {
  const [view, setView] = useState<string>('boot-tv');
  const [openWindows, setOpenWindows] = useState<Array<{ id: string; icon: React.ElementType; title: string }>>([]);
  const [activeWindow, setActiveWindow] = useState<string | null>(null);
  const [windowPositions, setWindowPositions] = useState<Record<string, { x: number; y: number }>>({});
  const [assets, setAssets] = useState<Record<string, string>>({});
  const [currentScene, setCurrentScene] = useState(0);
  const [scare, setScare] = useState(false);
  const [time, setTime] = useState('');
  const [osPassword, setOsPassword] = useState('');
  const [loginError, setLoginError] = useState(false);
  const dragRef = useRef<{ id: string; startX: number; startY: number } | null>(null);

  useEffect(() => {
    const updateTime = () => setTime(new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }));
    updateTime();
    const t = setInterval(updateTime, 1000);
    return () => clearInterval(t);
  }, []);

  useEffect(() => {
    if (view === 'boot-tv') setTimeout(() => setView('boot-vhs'), 3000);
    else if (view === 'boot-vhs') setTimeout(() => setView('login'), 4000);
  }, [view]);

  const handleDragStart = (id: string, e: React.MouseEvent | React.TouchEvent) => {
    setActiveWindow(id);
    const clientX = 'touches' in e ? e.touches[0].clientX : e.clientX;
    const clientY = 'touches' in e ? e.touches[0].clientY : e.clientY;
    dragRef.current = {
      id,
      startX: clientX - (windowPositions[id]?.x || 0),
      startY: clientY - (windowPositions[id]?.y || 0)
    };
    const move = (me: MouseEvent | TouchEvent) => {
      if (!dragRef.current) return;
      const mX = 'touches' in me ? (me as TouchEvent).touches[0].clientX : (me as MouseEvent).clientX;
      const mY = 'touches' in me ? (me as TouchEvent).touches[0].clientY : (me as MouseEvent).clientY;
      setWindowPositions(prev => ({
        ...prev,
        [dragRef.current!.id]: { x: mX - dragRef.current!.startX, y: mY - dragRef.current!.startY }
      }));
    };
    const stop = () => {
      dragRef.current = null;
      window.removeEventListener('mousemove', move);
      window.removeEventListener('mouseup', stop);
      window.removeEventListener('touchmove', move);
      window.removeEventListener('touchend', stop);
    };
    window.addEventListener('mousemove', move);
    window.addEventListener('mouseup', stop);
    window.addEventListener('touchmove', move, { passive: false });
    window.addEventListener('touchend', stop);
  };

  const toggleWindow = (id: string, icon: React.ElementType, title: string) => {
    if (openWindows.find(w => w.id === id)) {
      setActiveWindow(id);
    } else {
      setOpenWindows([...openWindows, { id, icon, title }]);
      const x = Math.max(20, (window.innerWidth / 2) - 170 + (openWindows.length * 20));
      const y = Math.max(50, (window.innerHeight / 2) - 200 + (openWindows.length * 20));
      setWindowPositions(prev => ({ ...prev, [id]: { x, y } }));
      setActiveWindow(id);
    }
  };

  const closeWindow = (id: string) => {
    setOpenWindows(openWindows.filter(w => w.id !== id));
    if (activeWindow === id) setActiveWindow(null);
  };

  const handleOsLogin = () => {
    if (osPassword === 'MASSG') {
      setView('desktop');
      setLoginError(false);
    } else {
      setLoginError(true);
      setTimeout(() => setLoginError(false), 3000);
    }
  };

  const pcmToWav = (pcmData: string) => {
    const buffer = Uint8Array.from(atob(pcmData), c => c.charCodeAt(0));
    const header = new ArrayBuffer(44);
    const v = new DataView(header);
    const s = (o: number, str: string) => { for (let i = 0; i < str.length; i++) v.setUint8(o + i, str.charCodeAt(i)); };
    s(0, 'RIFF'); v.setUint32(4, 36 + buffer.length, true); s(8, 'WAVE'); s(12, 'fmt ');
    v.setUint32(16, 16, true); v.setUint16(20, 1, true); v.setUint16(22, 1, true);
    v.setUint32(24, 24000, true); v.setUint32(28, 48000, true); v.setUint16(32, 2, true);
    v.setUint16(34, 16, true); s(36, 'data'); v.setUint32(40, buffer.length, true);
    const wav = new Uint8Array(header.byteLength + buffer.length);
    wav.set(new Uint8Array(header), 0); wav.set(buffer, header.byteLength);
    return URL.createObjectURL(new Blob([wav], { type: 'audio/wav' }));
  };

  const runFilm = async () => {
    setView('loading');
    const cache: Record<string, string> = {};
    try {
      for (const act of SCRIPT_ACTS) {
        const [imgRes, ttsRes] = await Promise.all([
          fetch(`https://generativelanguage.googleapis.com/v1beta/models/imagen-4.0-generate-001:predict?key=${apiKey}`, {
            method: 'POST',
            body: JSON.stringify({ instances: [{ prompt: act.prompt }], parameters: { sampleCount: 1 } })
          }),
          fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-preview-tts:generateContent?key=${apiKey}`, {
            method: 'POST',
            body: JSON.stringify({
              contents: [{ parts: [{ text: `${act.dialogue.speaker} says in a glitchy horror voice: ${act.dialogue.text}` }] }],
              generationConfig: { responseModalities: ["AUDIO"], speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: act.dialogue.voice } } } }
            })
          })
        ]);
        const img = await imgRes.json();
        const tts = await ttsRes.json();
        cache[`${act.id}_img`] = `data:image/png;base64,${img.predictions[0].bytesBase64Encoded}`;
        cache[`${act.id}_audio`] = pcmToWav(tts.candidates[0].content.parts[0].inlineData.data);
      }
      setAssets(cache);
      setView('player');
      setCurrentScene(0);
    } catch (e: any) {
      alert("CRITICAL ERROR: " + e.message);
      setView('desktop');
    }
  };

  useEffect(() => {
    if (view === 'player') {
      const act = SCRIPT_ACTS[currentScene];
      if (!act || !assets[`${act.id}_audio`]) return;
      if (act.scare) { setScare(true); setTimeout(() => setScare(false), 2000); }
      const audio = new Audio(assets[`${act.id}_audio`]);
      audio.play();
      const t = setTimeout(() => {
        if (currentScene < SCRIPT_ACTS.length - 1) setCurrentScene(s => s + 1);
        else setView('desktop');
      }, act.duration);
      return () => { clearTimeout(t); audio.pause(); };
    }
  }, [view, currentScene, assets]);

  // --- SUB-APP RENDERERS ---
  const BrowserApp = () => (
    <div className="bg-[#c0c0c0] text-black font-mono text-xs">
      <div className="bg-[#c0c0c0] p-1 border-b-2 border-zinc-500">
        <div className="flex items-center gap-1">
          <span className="text-[9px] font-bold">Address:</span>
          <div className="flex-1 bg-white border border-zinc-400 px-2 py-0.5 text-[10px]">
            http://www.classified.gov/void-bridge/nodes
          </div>
          <button className="bg-[#c0c0c0] border-2 border-t-white border-l-white border-b-zinc-800 border-r-zinc-800 px-2 py-0.5 text-[9px] font-bold">Go</button>
        </div>
      </div>
      <div className="bg-black text-emerald-500 p-4 min-h-[200px]">
        <div className="border border-emerald-900 p-3 mb-3">
          <h2 className="text-sm font-bold text-emerald-400">RESTRICTED_NODE_ACCESS</h2>
          <span className="text-[9px] text-red-500 font-bold">TOP_SECRET</span>
        </div>
        <p className="text-[10px] leading-relaxed mb-3 text-emerald-700">
          "The Minecraft world was never just a sandbox. It was a containment unit for corrupted neural data."
        </p>
        <div className="space-y-1">
          {['NODE_09: BLUE_EYE_MUTATION', 'NODE_14: SEED_DELETION'].map(n => (
            <p key={n} className="text-[9px] text-emerald-600 hover:text-emerald-400 cursor-pointer">{'>'} {n}</p>
          ))}
        </div>
      </div>
    </div>
  );

  const MailApp = () => (
    <div className="p-3 space-y-2">
      <div className="space-y-2">
        {ENCRYPTED_MAIL.map((m, i) => (
          <div key={i} className="border border-emerald-900/50 p-3 bg-black/50 hover:border-emerald-500/50 transition-colors">
            <div className="flex justify-between items-center mb-1">
              <span className="text-emerald-500 font-bold text-[10px]">From: {m.from}</span>
              <span className="text-zinc-600 text-[8px]">04-03-94</span>
            </div>
            <h3 className="text-emerald-400 text-xs font-bold">{m.subject}</h3>
            <p className="text-zinc-500 text-[10px] mt-1">{m.body}</p>
          </div>
        ))}
      </div>
    </div>
  );

  const DatabaseApp = () => (
    <div className="p-3 space-y-4">
      <div>
        <h3 className="text-emerald-500 font-bold text-xs mb-2 border-b border-emerald-900 pb-1">Subject_Profiles</h3>
        {LORE_DB.characters.map(c => (
          <div key={c.id} className="mb-3 border-l-2 border-emerald-800 pl-3">
            <div className="flex justify-between">
              <span className="text-emerald-400 font-bold text-[11px]">{c.name}</span>
              <span className="text-zinc-600 text-[9px]">{c.id}</span>
            </div>
            <p className="text-red-500 text-[9px] font-bold">STATUS: {c.status}</p>
            <p className="text-zinc-500 text-[10px] italic">"{c.lore}"</p>
          </div>
        ))}
      </div>
      <div>
        <h3 className="text-red-500 font-bold text-xs mb-2 border-b border-red-900 pb-1">ANOMALY_LOGS</h3>
        {LORE_DB.entities.map(e => (
          <div key={e.name} className="mb-3 border-l-2 border-red-800 pl-3">
            <div className="flex justify-between">
              <span className="text-red-400 font-bold text-[11px]">{e.name}</span>
              <span className="text-zinc-600 text-[9px]">{e.type}</span>
            </div>
            <p className="text-amber-500 text-[9px]">Threat Level: {e.threat}</p>
            <p className="text-zinc-500 text-[10px]">{e.description}</p>
          </div>
        ))}
      </div>
    </div>
  );

  const DevBuildsApp = () => (
    <div className="p-3 space-y-2">
      {DEV_BUILDS.map((b, i) => (
        <div key={i} className="border border-emerald-900/50 p-2 bg-black/50 flex justify-between items-center">
          <div>
            <p className="text-emerald-400 text-[10px] font-bold">{b.name}</p>
            <p className="text-zinc-600 text-[8px]">{b.size} // {b.date}</p>
            <p className="text-zinc-500 text-[9px]">{b.desc}</p>
          </div>
          <Download size={12} className="text-emerald-700" />
        </div>
      ))}
    </div>
  );

  const NotesApp = () => (
    <div className="p-3 space-y-2">
      <div className="border border-red-900 p-3 bg-red-950/20">
        <div className="flex items-center gap-2 mb-2">
          <AlertTriangle size={12} className="text-red-500" />
          <span className="text-red-500 font-bold text-[10px]">SYSTEM_ALERT_001</span>
        </div>
        <p className="text-zinc-400 text-[10px]">Reality anchor destabilizing. Sector 7 showing signs of data corruption. All personnel evacuate immediately.</p>
      </div>
      <div className="border border-amber-900 p-3 bg-amber-950/20">
        <div className="flex items-center gap-2 mb-2">
          <ShieldAlert size={12} className="text-amber-500" />
          <span className="text-amber-500 font-bold text-[10px]">CONTAINMENT_BREACH</span>
        </div>
        <p className="text-zinc-400 text-[10px]">Entity "MASSG" has breached containment protocol 7-Alpha. Recommend full system purge.</p>
      </div>
    </div>
  );

  const CmdApp = () => {
    const [cmdHistory, setCmdHistory] = useState<string[]>([
      'MASSG_OS [Version 4.2.1994]',
      '(C) Creator Corp. All realities reserved.',
      '',
      'C:\\MASSG>'
    ]);
    const [cmdInput, setCmdInput] = useState('');
    const handleCmd = () => {
      const responses: Record<string, string> = {
        'help': 'Available: dir, cls, scan, status, exit',
        'dir': 'MASSG.exe  VOID.dll  SEED.dat  ANNA.log  TRAVIS.log  TONYA.log',
        'scan': 'SCANNING... 3 subjects found. 2 entities detected. 1 UNKNOWN.',
        'status': 'SYSTEM: CRITICAL // REALITY: UNSTABLE // CREATOR: WATCHING',
        'cls': '',
      };
      const resp = responses[cmdInput.toLowerCase()] || `'${cmdInput}' is not recognized as an internal or external command.`;
      if (cmdInput.toLowerCase() === 'cls') {
        setCmdHistory(['C:\\MASSG>']);
      } else {
        setCmdHistory(prev => [...prev, `C:\\MASSG> ${cmdInput}`, resp, '', 'C:\\MASSG>']);
      }
      setCmdInput('');
    };
    return (
      <div className="bg-black p-2 font-mono text-[10px] text-emerald-500 min-h-[200px]">
        {cmdHistory.map((line, i) => <div key={i}>{line || '\u00A0'}</div>)}
        <div className="flex">
          <input
            value={cmdInput}
            onChange={e => setCmdInput(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && handleCmd()}
            className="bg-transparent outline-none flex-1 text-emerald-500 caret-emerald-500"
            autoFocus
          />
        </div>
      </div>
    );
  };

  const CCTVApp = () => {
    const [activeCam, setActiveCam] = useState(0);
    const [feed, setFeed] = useState<string | null>(null);
    const [loading, setLoading] = useState(false);

    const getFeed = async (idx: number) => {
      setLoading(true);
      setActiveCam(idx);
      try {
        const res = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/imagen-4.0-generate-001:predict?key=${apiKey}`, {
          method: 'POST',
          body: JSON.stringify({ instances: [{ prompt: CCTV_NODES[idx].prompt }], parameters: { sampleCount: 1 } })
        });
        const data = await res.json();
        setFeed(`data:image/png;base64,${data.predictions[0].bytesBase64Encoded}`);
      } catch {
        setFeed(null);
      }
      setLoading(false);
    };

    useEffect(() => { getFeed(0); }, []);

    return (
      <div className="flex flex-col">
        <div className="relative bg-black aspect-video">
          {loading ? (
            <div className="absolute inset-0 flex items-center justify-center">
              <p className="text-emerald-500 font-mono text-xs animate-pulse">CONNECTING_TO_NODE...</p>
            </div>
          ) : feed ? (
            <img src={feed} alt="CCTV Feed" className="w-full h-full object-cover" />
          ) : (
            <div className="absolute inset-0 flex items-center justify-center">
              <p className="text-red-500 font-mono text-xs">SIGNAL_LOSS_00x00</p>
            </div>
          )}
          <div className="absolute top-2 left-2 text-emerald-500 font-mono text-[9px] font-bold">
            LIVE // {CCTV_NODES[activeCam].name}
          </div>
          <div className="absolute top-2 right-2 text-red-500 font-mono text-[9px] animate-pulse">
            REC [●] 16:15:00
          </div>
          <VHSOverlay color="lime" />
        </div>
        <div className="grid grid-cols-3 gap-1 p-2 bg-zinc-900">
          {CCTV_NODES.map((cam, i) => (
            <button
              key={cam.id}
              onClick={() => getFeed(i)}
              className={`text-[8px] py-1 border font-black transition-all ${activeCam === i ? 'bg-emerald-800 border-emerald-500 text-white shadow-[0_0_10px_rgba(34,197,94,0.5)]' : 'bg-zinc-900 border-zinc-700 text-emerald-500'}`}
            >
              CAM_0{i + 1}
            </button>
          ))}
        </div>
      </div>
    );
  };

  // --- MAIN RENDER ---
  const renderView = () => {
    switch (view) {
      case 'boot-tv':
        return (
          <div className="fixed inset-0 bg-black flex items-center justify-center z-[9999]">
            <div className="relative w-full max-w-2xl aspect-[4/3]">
              <div className="absolute inset-0 flex">
                {['#ffffff', '#ffff00', '#00ffff', '#00ff00', '#ff00ff', '#ff0000', '#0000ff'].map(c => (
                  <div key={c} className="flex-1 h-full" style={{ backgroundColor: c }} />
                ))}
              </div>
              <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/70">
                <div className="bg-black/80 px-6 py-4 border border-white/20">
                  <p className="text-white font-mono text-lg font-bold tracking-widest">NO SIGNAL</p>
                  <p className="text-zinc-500 font-mono text-[10px] text-center mt-1">Creator Station // Sector 00-FF</p>
                </div>
              </div>
            </div>
            <VHSOverlay />
          </div>
        );

      case 'boot-vhs':
        return (
          <div className="fixed inset-0 bg-black flex items-center justify-center z-[9999]">
            <VHSOverlay color="lime" />
            <div className="relative z-10 text-center">
              <div className="w-16 h-16 border-4 border-emerald-500 border-t-transparent rounded-full animate-spin mx-auto mb-6" />
              <h1 className="text-emerald-500 font-mono text-xl font-bold tracking-[0.3em] mb-4">MASSG_OS LOADING...</h1>
              <div className="w-64 h-1 bg-zinc-800 mx-auto rounded overflow-hidden">
                <div className="h-full bg-emerald-500 animate-pulse" style={{ width: '60%' }} />
              </div>
              <div className="mt-6 text-left mx-auto max-w-xs space-y-1">
                <p className="text-emerald-700 font-mono text-[10px]">{'>'} BIOS v4.2 CHECKING... OK</p>
                <p className="text-emerald-700 font-mono text-[10px]">{'>'} MOUNTING /dev/reality_bridge... OK</p>
                <p className="text-emerald-700 font-mono text-[10px]">{'>'} CONNECTING NEURAL_LINK... SUCCESS</p>
                <p className="text-emerald-700 font-mono text-[10px]">{'>'} SCANNING SUBJECTS... 3 FOUND</p>
              </div>
              <p className="text-emerald-500 font-mono text-[10px] mt-4 animate-pulse">AUTHENTICATION COMPLETE. WELCOME ADMIN.</p>
            </div>
          </div>
        );

      case 'login':
        return (
          <div className="fixed inset-0 bg-black flex items-center justify-center z-[9999]">
            <VHSOverlay color="lime" />
            <div className="relative z-10 w-full max-w-sm">
              <div className="border border-emerald-900 bg-black/90 p-8">
                <div className="w-12 h-12 border-2 border-emerald-500 rounded-full flex items-center justify-center mx-auto mb-4">
                  <User size={20} className="text-emerald-500" />
                </div>
                <h2 className="text-emerald-500 font-mono text-center font-bold tracking-[0.3em] mb-6">ADMIN LOGIN</h2>
                <div className="space-y-4">
                  <div>
                    <label className="text-emerald-700 font-mono text-[10px] block mb-1">Identity_Token</label>
                    <input
                      type="password"
                      value={osPassword}
                      onChange={(e) => setOsPassword(e.target.value)}
                      onKeyDown={(e) => e.key === 'Enter' && handleOsLogin()}
                      placeholder="••••••••"
                      className="w-full bg-black border border-emerald-900 p-3 text-emerald-500 outline-none focus:border-emerald-400 transition-colors placeholder:text-emerald-900 font-mono text-sm"
                    />
                  </div>
                  <button onClick={handleOsLogin} className="w-full bg-emerald-900/50 border border-emerald-700 text-emerald-400 py-2 font-mono text-xs tracking-widest hover:bg-emerald-800 transition-colors">
                    Login Session
                  </button>
                  <button
                    onClick={() => { setOsPassword('MASSG'); setView('desktop'); }}
                    className="w-full text-[9px] text-emerald-900 hover:text-emerald-400 transition-colors uppercase font-black tracking-widest text-center font-mono"
                  >
                    [ Emergency Admin Bypass ]
                  </button>
                </div>
                {loginError && (
                  <div className="mt-4 bg-[#c0c0c0] border-2 border-t-white border-l-white border-b-zinc-800 border-r-zinc-800 p-3">
                    <div className="flex items-center gap-2 mb-2">
                      <AlertTriangle size={14} className="text-red-600" />
                      <span className="text-black font-bold text-[11px]">Restricted Access</span>
                    </div>
                    <p className="text-black text-[10px] mb-2">INVALID IDENTITY TOKEN. UNAUTHORIZED ATTEMPTS ARE LOGGED.</p>
                    <button
                      onClick={() => setLoginError(false)}
                      className="bg-[#c0c0c0] border-2 border-t-white border-l-white border-b-zinc-800 border-r-zinc-800 px-4 py-1 text-[10px] font-bold float-right active:border-b-white active:border-r-white"
                    >
                      OK
                    </button>
                  </div>
                )}
                <p className="text-emerald-900 font-mono text-[8px] text-center mt-6">
                  Unauthorized attempts will be traced to physical location.
                </p>
              </div>
            </div>
          </div>
        );

      case 'loading':
        return (
          <div className="fixed inset-0 bg-black flex flex-col items-center justify-center z-[9999]">
            <div className="relative">
              <Skull size={64} className="text-emerald-500 animate-pulse" />
            </div>
            <div className="mt-6 text-center">
              <h2 className="text-emerald-500 font-mono text-lg font-bold tracking-widest">FEEDING THE CREATOR</h2>
              <p className="text-emerald-700 font-mono text-xs mt-2">Rendering Reality Fragments...</p>
            </div>
            <div className="mt-6 w-48 h-1 bg-zinc-800 rounded overflow-hidden">
              <div className="h-full bg-emerald-500 animate-pulse" style={{ width: '45%' }} />
            </div>
          </div>
        );

      case 'player':
        return (
          <div className="fixed inset-0 bg-black z-[9999]">
            <VHSOverlay color="lime" />
            <div className="absolute inset-0">
              {assets[`${SCRIPT_ACTS[currentScene].id}_img`] && (
                <img src={assets[`${SCRIPT_ACTS[currentScene].id}_img`]} alt="Scene" className="w-full h-full object-cover" />
              )}
              {scare && (
                <div className="absolute inset-0 bg-red-900/80 flex items-center justify-center z-[4020] animate-pulse">
                  <Skull size={200} className="text-white animate-bounce" />
                </div>
              )}
              <div className="absolute bottom-20 left-0 right-0 text-center z-[4010]">
                <h2 className="text-emerald-400 font-mono text-2xl font-bold tracking-widest">{SCRIPT_ACTS[currentScene].title}</h2>
                <p className="text-emerald-700 font-mono text-[10px] mt-1">ACT_0{currentScene + 1} // MASSG</p>
              </div>
              <div className="absolute bottom-4 left-4 right-4 z-[4010]">
                <div className="bg-black/80 border border-emerald-900 p-3">
                  <p className="text-emerald-500 font-mono text-[10px] font-bold">{SCRIPT_ACTS[currentScene].dialogue.speaker}</p>
                  <p className="text-emerald-400 font-mono text-xs italic">"{SCRIPT_ACTS[currentScene].dialogue.text}"</p>
                </div>
              </div>
              <button onClick={() => setView('desktop')} className="absolute top-4 right-4 bg-white/5 p-2 text-emerald-400 hover:bg-emerald-700 hover:text-white transition-all z-[4030]">
                <X size={16} />
              </button>
            </div>
          </div>
        );

      default: // THE MASSG DESKTOP
        return (
          <div className="fixed inset-0 bg-black overflow-hidden select-none" style={{ fontFamily: "'Courier New', monospace" }}>
            <VHSOverlay color="lime" />

            {/* Desktop Background */}
            <div className="absolute inset-0 bg-gradient-to-br from-black via-zinc-950 to-black" />
            <div className="absolute inset-0 opacity-5" style={{ backgroundImage: 'url("data:image/svg+xml,%3Csvg width=\'40\' height=\'40\' xmlns=\'http://www.w3.org/2000/svg\'%3E%3Cpath d=\'M0 0h40v40H0z\' fill=\'none\' stroke=\'%2300ff00\' stroke-width=\'0.5\'/%3E%3C/svg%3E")', backgroundSize: '40px 40px' }} />

            {/* Desktop Icons */}
            <div className="absolute top-2 left-2 grid grid-cols-2 gap-1 z-10">
              <DesktopIcon icon={Database} label="Classified Database" onClick={() => toggleWindow('db', Database, 'Classified Database')} />
              <DesktopIcon icon={Film} label="Run MASSG Film" onClick={runFilm} color="text-red-500" />
              <DesktopIcon icon={Camera} label="CCTV Network" onClick={() => toggleWindow('cctv', Camera, 'MASSG Security Network')} color="text-blue-500" />
              <DesktopIcon icon={Lock} label="Secrets" onClick={() => toggleWindow('dev', Lock, 'Secrets Directory')} color="text-emerald-500" />
              <DesktopIcon icon={Mail} label="Encrypted Mail" onClick={() => toggleWindow('mail', Mail, 'Encrypted Intercepts')} color="text-amber-500" />
              <DesktopIcon icon={Map} label="Void Map" onClick={() => toggleWindow('maps', Map, 'Void Coordinates')} color="text-indigo-400" />
              <DesktopIcon icon={Globe} label="NetScape 0.9" onClick={() => toggleWindow('browser', Globe, 'NetScape 0.9')} color="text-white" />
              <DesktopIcon icon={Terminal} label="MS-DOS" onClick={() => toggleWindow('cmd', Terminal, 'MS-DOS Prompt')} color="text-emerald-400" />
              <DesktopIcon icon={Trash2} label="Recycle Bin" onClick={() => {}} color="text-zinc-600" />
              <DesktopIcon icon={FileText} label="System Alerts" onClick={() => toggleWindow('notes', FileText, 'System Alerts')} color="text-red-500" />
              <DesktopIcon icon={HardDrive} label="C:\\ Drive" onClick={() => {}} color="text-emerald-700" />
              <DesktopIcon icon={Wifi} label="NEURAL_LINK" onClick={() => {}} color="text-emerald-300" />
            </div>

            {/* Window Layer */}
            {openWindows.map(w => (
              <DraggableWindow
                key={w.id}
                id={w.id}
                title={w.title}
                icon={w.icon}
                isActive={activeWindow === w.id}
                onFocus={() => setActiveWindow(w.id)}
                onClose={() => closeWindow(w.id)}
                position={windowPositions[w.id] || { x: 350, y: 150 }}
                onDragStart={(e) => handleDragStart(w.id, e)}
              >
                {w.id === 'browser' && <BrowserApp />}
                {w.id === 'db' && <DatabaseApp />}
                {w.id === 'dev' && <DevBuildsApp />}
                {w.id === 'cctv' && <CCTVApp />}
                {w.id === 'notes' && <NotesApp />}
                {w.id === 'cmd' && <CmdApp />}
                {w.id === 'mail' && <MailApp />}
                {w.id === 'maps' && (
                  <div className="p-4 min-h-[200px] flex items-center justify-center">
                    <div className="text-center">
                      <Map size={32} className="text-indigo-500 mx-auto mb-2 animate-pulse" />
                      <p className="text-zinc-500 font-mono text-[10px]">Map rendering unavailable. Sector 7 is undergoing deletion.</p>
                    </div>
                  </div>
                )}
              </DraggableWindow>
            ))}

            {/* Taskbar */}
            <div className="absolute bottom-0 left-0 right-0 h-8 bg-[#c0c0c0] border-t-2 border-white flex items-center px-1 z-[5000]" style={{ fontFamily: 'Tahoma, sans-serif' }}>
              <div className="relative group">
                <button className="flex items-center gap-1 bg-[#c0c0c0] border-2 border-t-white border-l-white border-b-zinc-800 border-r-zinc-800 px-3 py-0.5 font-bold text-[11px] active:border-b-white active:border-r-white">
                  <Monitor size={14} />
                  Start
                </button>
                <div className="hidden group-hover:block absolute bottom-full left-0 w-48 bg-[#c0c0c0] border-2 border-t-white border-l-white border-b-zinc-800 border-r-zinc-800 shadow-lg">
                  <div className="bg-[#000080] text-white text-[9px] px-2 py-1 font-bold">MASSG_OS // ADMIN</div>
                  <button onClick={() => { setOsPassword(''); setView('login'); }} className="w-full text-left px-4 py-2 hover:bg-[#000080] hover:text-white text-xs flex items-center gap-2 transition-colors">
                    <User size={12} /> Switch Account
                  </button>
                  <button onClick={() => { setAssets({}); setOsPassword(''); setView('boot-tv'); }} className="w-full text-left px-4 py-2 hover:bg-red-800 hover:text-white text-xs flex items-center gap-2 transition-colors">
                    <Power size={12} /> Log Off Session
                  </button>
                  <p className="text-[8px] text-zinc-500 px-4 py-1 border-t border-zinc-400">The Creator is watching.</p>
                </div>
              </div>

              <div className="flex-1 flex items-center gap-1 mx-2 overflow-x-auto">
                {openWindows.map(w => (
                  <button
                    key={w.id}
                    onClick={() => setActiveWindow(w.id)}
                    className={`flex items-center gap-2 px-3 py-1 text-[10px] font-bold border-2 max-w-[150px] truncate transition-all ${activeWindow === w.id ? 'bg-[#dcdcdc] border-b-white border-r-white border-t-zinc-800 border-l-zinc-800' : 'bg-[#c0c0c0] border-t-white border-l-white border-b-zinc-800 border-r-zinc-800'}`}
                  >
                    {w.title}
                  </button>
                ))}
              </div>

              <div className="flex items-center gap-2 border-2 border-b-white border-r-white border-t-zinc-800 border-l-zinc-800 px-2 py-0.5 text-[10px] font-mono">
                <Activity size={10} className="text-emerald-600" />
                <span className="text-zinc-700">SEED_SYNC</span>
                <span className="text-black font-bold">{time}</span>
              </div>
            </div>
          </div>
        );
    }
  };

  return (
    <div className="w-full h-screen overflow-hidden">
      {/* Universal CRT Flicker */}
      <div className="pointer-events-none fixed inset-0 z-[10000]" style={{ background: 'repeating-linear-gradient(0deg, rgba(0,0,0,0.03) 0px, rgba(0,0,0,0.03) 1px, transparent 1px, transparent 2px)', mixBlendMode: 'multiply' }} />
      {renderView()}
    </div>
  );
};

// --- VAULT PAGE (Password Gate) ---
const Vault = () => {
  const [unlocked, setUnlocked] = useState(false);
  const [token, setToken] = useState('');
  const [error, setError] = useState(false);
  const [shake, setShake] = useState(false);

  const handleSubmit = () => {
    if (token === 'MASSG123!§§231115') {
      setUnlocked(true);
    } else {
      setError(true);
      setShake(true);
      setTimeout(() => setShake(false), 600);
      setTimeout(() => setError(false), 3000);
    }
  };

  if (unlocked) {
    return <MassgOS />;
  }

  return (
    <div className="fixed inset-0 bg-black flex items-center justify-center overflow-hidden">
      {/* Scanlines */}
      <div className="pointer-events-none absolute inset-0 z-50" style={{ background: 'repeating-linear-gradient(0deg, rgba(0,0,0,0.15) 0px, rgba(0,0,0,0.15) 1px, transparent 1px, transparent 2px)' }} />
      {/* Grid background */}
      <div className="absolute inset-0 opacity-[0.03]" style={{ backgroundImage: 'url("data:image/svg+xml,%3Csvg width=\'40\' height=\'40\' xmlns=\'http://www.w3.org/2000/svg\'%3E%3Cpath d=\'M0 0h40v40H0z\' fill=\'none\' stroke=\'%2300ff00\' stroke-width=\'0.5\'/%3E%3C/svg%3E")', backgroundSize: '40px 40px' }} />

      <div className={`relative z-10 w-full max-w-md px-6 transition-transform ${shake ? 'animate-[shake_0.6s_ease-in-out]' : ''}`}>
        <div className="border border-emerald-900/50 bg-black/90 backdrop-blur-sm p-8 shadow-[0_0_60px_rgba(16,185,129,0.05)]">
          {/* Header */}
          <div className="text-center mb-8">
            <div className="w-16 h-16 border-2 border-emerald-800 rounded-full flex items-center justify-center mx-auto mb-4 relative">
              <Lock size={24} className="text-emerald-600" />
              <div className="absolute inset-0 border-2 border-emerald-500/20 rounded-full animate-ping" />
            </div>
            <h1 className="font-mono text-emerald-500 text-lg font-bold tracking-[0.4em]">CLASSIFIED</h1>
            <p className="font-mono text-emerald-900 text-[9px] tracking-[0.3em] mt-1">WITHERING REWRITE AWAKENING STUDIOS</p>
          </div>

          {/* Input */}
          <div className="space-y-4">
            <div>
              <label className="font-mono text-emerald-700 text-[10px] tracking-[0.2em] block mb-2">IDENTITY_TOKEN</label>
              <input
                type="password"
                value={token}
                onChange={(e) => setToken(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSubmit()}
                placeholder="Enter access token..."
                className="w-full bg-black border border-emerald-900/60 px-4 py-3 text-emerald-400 font-mono text-sm outline-none focus:border-emerald-500 transition-colors placeholder:text-emerald-950"
              />
            </div>

            <button
              onClick={handleSubmit}
              className="w-full border border-emerald-800 bg-emerald-950/30 text-emerald-500 font-mono text-xs tracking-[0.3em] py-3 hover:bg-emerald-900/40 hover:border-emerald-600 transition-all"
            >
              AUTHENTICATE
            </button>
          </div>

          {/* Error */}
          {error && (
            <div className="mt-4 border border-red-900/50 bg-red-950/20 p-3 flex items-center gap-2">
              <AlertTriangle size={14} className="text-red-500 shrink-0" />
              <p className="font-mono text-red-500 text-[10px]">ACCESS DENIED. UNAUTHORIZED ATTEMPT LOGGED.</p>
            </div>
          )}

          {/* Footer */}
          <div className="mt-8 text-center">
            <p className="font-mono text-emerald-950 text-[8px] tracking-[0.2em]">
              ALL ACCESS ATTEMPTS ARE MONITORED AND RECORDED
            </p>
            <div className="flex items-center justify-center gap-2 mt-2">
              <div className="w-1.5 h-1.5 rounded-full bg-emerald-800 animate-pulse" />
              <p className="font-mono text-emerald-900 text-[8px]">SYSTEM ACTIVE</p>
            </div>
          </div>
        </div>
      </div>

      {/* Shake animation */}
      <style>{`
        @keyframes shake {
          0%, 100% { transform: translateX(0); }
          10%, 30%, 50%, 70%, 90% { transform: translateX(-4px); }
          20%, 40%, 60%, 80% { transform: translateX(4px); }
        }
      `}</style>
    </div>
  );
};

export default Vault;
